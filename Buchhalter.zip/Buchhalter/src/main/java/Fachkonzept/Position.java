/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Fachkonzept;

/**
 *
 * @author user
 */
public class Position {
    private Artikel artikel;
    private int iMenge;
    private int iRabatt;
    private double dSummeNetto;
    private double dSteuer;
    private double dSummeBrutto;

    public int getiMenge() {
        return iMenge;
    }

    public int getiRabatt() {
        return iRabatt;
    }

    public double getdSummeNetto() {
        return dSummeNetto;
    }

    public double getdSteuer() {
        return dSteuer;
    }

    public double getdSummeBrutto() {
        return dSummeBrutto;
    }
    
    public void setArtikel(Artikel art)
    {
        this.artikel = art;
    }
    
    public void setMenge(int meng)
    {
        this.iMenge = meng;
    }
    
    public void setRabatt(int rabatt)
    {
        this.iRabatt = rabatt;
    }
    
    public void setSumme()
    {
        dSummeNetto = iMenge * artikel.getdStueckpreisNetto();
        dSummeNetto = dSummeNetto - ((dSummeNetto / 100)*iRabatt);
        
        dSteuer = (dSummeNetto / (100+artikel.getiSteuersatz()))/artikel.getiSteuersatz();
        dSummeBrutto = dSummeNetto + dSteuer;
    }
    
    public Artikel getArtikel()
    {
        return artikel;
    }
}
