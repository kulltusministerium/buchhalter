/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Fachkonzept;

/**
 *
 * @author user
 */
public class Buchung {
    private Konto soll;
    private Konto haben;
    private String sDatum;
    private String sText;
    private double dBetrag;
    private int iSteuerSatz;
    private int iNummer;
    
    public Buchung(int nummer,String datum, String text, Konto sSoll, Konto hHaben, double betrag, int steuer)
    {
        this.iNummer = nummer;
        this.sDatum = datum;
        this.sText = text;
        this.soll = sSoll;
        this.haben = hHaben;
        this.dBetrag = betrag;
        this.iSteuerSatz = steuer;
        
        sSoll.addSoll(betrag);
        hHaben.addHaben(betrag);
        
    }
    
    public double getSteuerBetrag()
    {
        double dSteuer = dBetrag*iSteuerSatz;
        return dSteuer;
    }
    
    public int getPeriode()
    {
        System.out.println(sDatum);
        if(sDatum.contains(".1.") || (sDatum.contains(".01.")))
        System.out.println("Januar");
        return 0;
        //return Integer.parseInt(split[1]);
    }
    
    public String getAllInfos()
    {
        double dSteuern = (dBetrag/(100+iSteuerSatz)) * iSteuerSatz;
        String sRueck = iNummer + " " + sDatum + " " + sText + " " + soll.getNummer() + "/" +haben.getNummer() + " € " + dBetrag + " (davon "+iSteuerSatz+"% Steuer = "+dSteuern+")"; 
        return sRueck;
    }
    
    public Konto getSoll()
    {
        return soll;
    }
    
    public Konto getHaben()
    {
        return haben;
    }
    
    public String getDatum()
    {
        return sDatum;
    }
    
    public String getText()
    {
        return sText;
    }
    
    public double getBetrag()
    {
        return dBetrag;
    }
    
    public int getSteuer()
    {
        return iSteuerSatz;
    }
    
    public int getNummer()
    {
        return iNummer;
    }
}
