package Fachkonzept;

import Daten.Daten;
import GUI.GUI;
import GUI.GUIMenu;
import javax.swing.JFrame;
import javax.swing.WindowConstants;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */



/**
 *
 * @author user
 */
public class Buchhalter {

    public static void main(String[] args) {
        /*
        Daten d = new Daten();
        Konto k1 = new Konto("1600", "Kasse",d.getAnzBuchungen());
        Konto k2 = new Konto("4400", "Erlöse",d.getAnzBuchungen());
        d.addKonto(k1);
        d.addKonto(k2);
        
        Buchung b1 = new Buchung(d.getNummerBuchung(),"12.12.2021","Testbarverkauf",k1,k2,50,19);        
        d.addBuchung(b1);
        Buchung b2 = new Buchung(d.getNummerBuchung(),"13.12.2021", "Verkauf",d.getKonto("1600"),d.getKonto("4400"),77.77,16);
        d.addBuchung(b2);
        
        System.out.println("Kontenübersicht");
        d.printAllKonten();
        System.out.println("Buchungsübersicht");
        d.printAllBuchungen();
        */
        GUIMenu g = new GUIMenu();
        g.setTitle("Eclipse");
        g.setVisible(true);
        g.pack();
    }
}
