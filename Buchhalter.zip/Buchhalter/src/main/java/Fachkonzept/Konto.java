/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Fachkonzept;

import java.util.Dictionary;

/**
 *
 * @author user
 */
public class Konto {
    private String sNummer;
    private String sBezeichnung;
    private double[] betraegeSoll;
    private double[] betraegeHaben;
    private String sArt;
    private String[][] steuerPos;
    private String USTPosVor;
    private String USTPosMel;
    private String steuerPosMod;
        
    public Konto(String nummer, String bezeichnung, int iAnzahlB)
    {
        this.sNummer = nummer;
        this.sBezeichnung = bezeichnung;
        this.betraegeSoll = new double[iAnzahlB];
        this.betraegeHaben = new double[iAnzahlB];
        steuerPos = new String[50][5];
        setArt();
    }
    
    public void changeNr(String nr)
    {
        this.sNummer=nr;
    }
    
    public void changeBez(String bez)
    {
        this.sBezeichnung = bez;
    }
    
    
    
    private void setArt()
    {
        if(sNummer.length() == 3)
        {
            sArt = "Anlage";
        }
        else if(sNummer.length() == 4)
        {                        
            if(sNummer.startsWith("1"))
            {
                sArt = "Umlauf";
            }
            else if(sNummer.startsWith("2"))
            {
                sArt = "Eigenkapital";
            }
            else if(sNummer.startsWith("3"))
            {
                sArt = "Fremdkapital";
            }
            else if(sNummer.startsWith("4"))
            {
                sArt = "Ertrag";
            }
            else if(sNummer.startsWith("5"))
            {
                sArt = "Aufwand";
            }
            else if(sNummer.startsWith("6"))
            {
                sArt = "Aufwand";
            }
            else if(sNummer.startsWith("7"))
            {
                sArt = "Ertrag/ Aufwand";
            }
            else if(sNummer.startsWith("8"))
            {
                sArt = "besonderer Aufwand";
            }
            else if(sNummer.startsWith("9"))
            {
                sArt = "Vortrag";
            }
        }
        else if(sNummer.length() == 5)
        {
            if(sNummer.startsWith("1"))
            {
                sArt = "Debitor";
            }
            else if(sNummer.startsWith("2"))
            {
                sArt = "Debitor";
            }
            else if(sNummer.startsWith("7"))
            {
                sArt = "Kreditor";
            }
            else if(sNummer.startsWith("8"))
            {
                sArt = "Kreditor";
            }
        }
    }
    
    public double getSaldo()
    {
        double dSaldo = 0;
        double dSummeSoll = 0;
        double dSummeHaben = 0;
        
        for (int i = 0; i < betraegeSoll.length; i++) {
            if(betraegeSoll[i] != 0)
            {
                dSummeSoll = dSummeSoll + betraegeSoll[i];
            }
        }
        
        for (int i = 0; i < betraegeHaben.length; i++) {
            if(betraegeHaben[i] != 0)
            {
                dSummeHaben = dSummeHaben + betraegeHaben[i];
            }
        }
        
        //Anlage, Umlauf, Eigenkapital, Fremdkapital, Ertrag, Aufwand, Ertrag/ Aufwand, besonderer Aufwand, Vortrag, Debitor, Kreditor
        switch(sArt)
        {
            case "Anlage":
                dSaldo = dSummeSoll - dSummeHaben;
                break;
            case "Umlauf":
                dSaldo = dSummeSoll - dSummeHaben;
                break;
            case "Eigenkapital":
                dSaldo = dSummeSoll - dSummeHaben;
                break;
            case "Fremdkapital":
                dSaldo = dSummeHaben - dSummeSoll;
                break;
            case "Ertrag":
                dSaldo = dSummeHaben - dSummeSoll;
                break;
            case "Aufwand":
                dSaldo = dSummeSoll - dSummeHaben;
                break;
            case "Ertrag/ Aufwand":
                dSaldo = dSummeSoll - dSummeHaben;
                break;
            case "besonderer Aufwand":
                dSaldo = dSummeSoll - dSummeHaben;
                break;
            case "Vortrag":
                dSaldo = dSummeSoll - dSummeHaben;
                break;
            case "Debitor":
                dSaldo = dSummeSoll - dSummeHaben;
                break;
            case "Kreditor":
                dSaldo = dSummeHaben - dSummeSoll;
                break;
        }
        
        return dSaldo;
    }
    
    public void addSoll(double betrag)
    {
        for (int i = 0; i < betraegeSoll.length; i++) {
            if(betraegeSoll[i] == 0)
            {
                betraegeSoll[i] = betrag;
                break;
            }
        }
    }
    
    public void addHaben(double betrag)
    {
        for (int i = 0; i < betraegeHaben.length; i++) {
            if(betraegeHaben[i] == 0)
            {
                betraegeHaben[i] = betrag;
                break;
            }
        }
    }
    
    public String getNummer()
    {
        return sNummer;
    }
    
    public String getBezeichnung()
    {
        return sBezeichnung;
    }
    
    public String getUstPosVor()
    {
        return USTPosVor;
    }
    
    public String getUstPosMel()
    {
        return USTPosMel;
    }   
    
    public String getSteuerPosMod()
    {
        return steuerPosMod;
    }
    
    public void setSteuerPos(String pos)
    {
        steuerPosMod = pos;
        String[] splitZeile = pos.split("-");
        for (int i = 0; i < splitZeile.length; i++) {
            //System.out.println(splitZeile[i]);
            String[] splitSpalte = splitZeile[i].split("#");
            //System.out.println(splitSpalte[i]);
            //split[0] = gültig ab, split[1] = Steuersatz, split[2] = Ust.Pos Vor., split[3] = Ust.Post Erkl., split[4] = Zusatzang
            steuerPos[i][0] = splitSpalte[0];
            steuerPos[i][1] = splitSpalte[1];
            steuerPos[i][2] = splitSpalte[2];
            steuerPos[i][3] = splitSpalte[3];
            steuerPos[i][4] = splitSpalte[4];  
            //String st = steuerPos[i][0]+" " +steuerPos[i][1]+" " +steuerPos[i][2]+" " +steuerPos[i][3]+" " +steuerPos[i][4];
            //PrintSteuer(st);
            this.USTPosVor = steuerPos[i][2];
            this.USTPosMel = steuerPos[i][3];
        }
    }
    
    private void PrintSteuer(String st)
    {
        System.out.println("Ausgabe: "+st);
    }
    
    public String[][] getSteuerPos()
    {
        return steuerPos;
    }
}
