/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Fachkonzept;

/**
 *
 * @author user
 */
public class Auftrag {
    private String sArt;
    private String sDatum;
    private Position[] positionen;
    private Kunde kunde;
    private int iNummer;
    private double summeNetto;
    private double steuer;
    private double summeBrutto;

    public Auftrag()
    {
        positionen = new Position[500];
    }
    
    public Position[] getPositionen()
    {
        return positionen;
    }
    
    public double getSumme()
    {
        return summeBrutto;
    }
    
    public void setSumme()
    {
        for (int i = 0; i < positionen.length; i++) {
            if(positionen[i] != null)
            {
                positionen[i].setSumme();
                summeNetto = positionen[i].getdSummeNetto();
                summeBrutto = positionen[i].getdSummeBrutto();
            }
        }
    }
    
    public String getsDatum() {
        return sDatum;
    }

    public void setsDatum(String sDatum) {
        this.sDatum = sDatum;
    }

    public Kunde getKunde() {
        return kunde;
    }

    public void setKunde(Kunde kunde) {
        this.kunde = kunde;
    }

    public int getiNummer() {
        return iNummer;
    }

    public void setiNummer(int iNummer) {
        this.iNummer = iNummer;
    }
    
    public void setArt(String art)
    {
        this.sArt = art;
    }
    
    public String getArt()
    {
        return sArt;
    }
    
    public Auftrag getAuftrag()
    {
        return this;
    }
    
    public void addPosition(Position pos)
    {
        for (int i = 0; i < positionen.length; i++) {
            if(positionen[i] == null)
            {
                positionen[i] = pos;
                break;
            }
        }
    }
    
    public void removePosition(Position pos)
    {
        for (int i = 0; i < positionen.length; i++) {
            if(positionen[i] != null)
            {
                if(positionen[i].getArtikel().getBezeichnung() == pos.getArtikel().getBezeichnung())
                {
                    positionen[i] = null;
                    break;
                }
            }
        }
    }
}
