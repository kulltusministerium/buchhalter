/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Fachkonzept;

/**
 *
 * @author user
 */
public class Artikel {
    private String sBezeichnung;
    private String sBeschreibung;
    private double dStueckpreisNetto;
    private int iSteuersatz;
    private int iNummer;
    
    public Artikel(int iNr,String bez, String beschr, double preis, int steuer)
    {
        this.iNummer = iNr;
        this.sBezeichnung = bez;
        this.sBeschreibung = beschr;
        this.dStueckpreisNetto = preis;
        this.iSteuersatz = steuer;
    }
    
    public void setNr(int nummer)
    {
        this.iNummer = nummer;
    }
    
    public int getNr()
    {
        return iNummer;
    }
    
    public String getBezeichnung()
    {
        return sBezeichnung;
    }
    
    public double getSteuerBetrag()
    {
        double betr = (dStueckpreisNetto/100)*iSteuersatz;
        return betr;
    }

    public String getsBeschreibung() {
        return sBeschreibung;
    }

    public void setsBeschreibung(String sBeschreibung) {
        this.sBeschreibung = sBeschreibung;
    }

    public double getdStueckpreisNetto() {
        return dStueckpreisNetto;
    }

    public int getiSteuersatz() {
        return iSteuersatz;
    }   

    public void setsBezeichnung(String sBezeichnung) {
        this.sBezeichnung = sBezeichnung;
    }

    public void setdStueckpreisNetto(double dStueckpreisNetto) {
        this.dStueckpreisNetto = dStueckpreisNetto;
    }

    public void setiSteuersatz(int iSteuersatz) {
        this.iSteuersatz = iSteuersatz;
    }
    
}
