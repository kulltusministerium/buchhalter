/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Fachkonzept;

import Daten.Daten;
import java.util.Hashtable;

/**
 *
 * @author user
 */
public class Steuerberechnung {
    private Daten dats;
    //private Hashtable<String, String> pos;
    private Konto[] k;
    private String[] posName;
    private double[] posWert;
    private int[] perZuBerrechnen;
    
    public Steuerberechnung()
    {        
        dats = Daten.getInstanz();
        //pos = new Hashtable<String, String>();
        k = dats.getKonten();
        posName = new String[60];
        posWert = new double[60];
        setupPos();
        
        if(perZuBerrechnen != null)
            getBetragFromKonto();
    }
    
    public double[] getWerte()
    {
        return posWert;
    }
    
    public String[] getNamen()
    {
        return posName;
    }
    
    public void setPerZuBerrechnen(String art)
    {
        switch(art)
        {
            case "Wirtschaftsjahr":
                perZuBerrechnen = new int[12];
                perZuBerrechnen[0] = 1;
                perZuBerrechnen[1] = 2;
                perZuBerrechnen[2] = 3;
                perZuBerrechnen[3] = 4;
                perZuBerrechnen[4] = 5;
                perZuBerrechnen[5] = 6;
                perZuBerrechnen[6] = 7;
                perZuBerrechnen[7] = 8;
                perZuBerrechnen[8] = 9;
                perZuBerrechnen[9] = 10;
                perZuBerrechnen[10] = 11;
                perZuBerrechnen[11] = 12;
                break;
            case "1. Quartal":
                perZuBerrechnen = new int[3];
                perZuBerrechnen[0] = 1;
                perZuBerrechnen[1] = 2;
                perZuBerrechnen[2] = 3;
                break;
            case "2. Quartal":
                perZuBerrechnen = new int[3];
                perZuBerrechnen[0] = 4;
                perZuBerrechnen[1] = 5;
                perZuBerrechnen[2] = 6;
                break;
            case "3. Quartal":
                perZuBerrechnen = new int[3];
                perZuBerrechnen[0] = 7;
                perZuBerrechnen[1] = 8;
                perZuBerrechnen[2] = 9;
                break;
            case "4. Quartal":
                perZuBerrechnen = new int[3];
                perZuBerrechnen[0] = 10;
                perZuBerrechnen[1] = 11;
                perZuBerrechnen[2] = 12;
                break;
            case "Januar":
                perZuBerrechnen = new int[1];
                perZuBerrechnen[0] = 1;
                break;
            case "Februar":
                perZuBerrechnen = new int[1];
                perZuBerrechnen[0] = 2;
                break;
            case "März":
                perZuBerrechnen = new int[1];
                perZuBerrechnen[0] = 3;
                break;
            case "April":
                perZuBerrechnen = new int[1];
                perZuBerrechnen[0] = 4;
                break;
            case "Mai":
                perZuBerrechnen = new int[1];
                perZuBerrechnen[0] = 5;
                break;
            case "Juni":
                perZuBerrechnen = new int[1];
                perZuBerrechnen[0] = 6;
                break;
            case "Juli":
                perZuBerrechnen = new int[1];
                perZuBerrechnen[0] = 7;
                break;
            case "August":
                perZuBerrechnen = new int[1];
                perZuBerrechnen[0] = 8;
                break;
            case "September":
                perZuBerrechnen = new int[1];
                perZuBerrechnen[0] = 9;
                break;
            case "Oktober":
                perZuBerrechnen = new int[1];
                perZuBerrechnen[0] = 10;
                break;
            case "November":
                perZuBerrechnen = new int[1];
                perZuBerrechnen[0] = 11;
                break;
            case "Dezember":
                perZuBerrechnen = new int[1];
                perZuBerrechnen[0] = 12;
                break;
        }
    }
            
    private void setupPos()
    {        
        posName[0] = "81";posName[1] = "St1";
        posName[2] = "86";posName[3] = "St2";
        posName[4] = "87";
        posName[5] = "35";posName[6] = "36";
        posName[7] = "77";
        posName[8] = "76";posName[9] = "80";
        posName[10] = "41";
        posName[11] = "44";
        posName[12] = "49";
        posName[13] = "43";
        posName[14] = "48";
        posName[15] = "91";
        posName[16] = "89";posName[16] = "VS1";
        posName[18] = "93";posName[19] = "VS2";
        posName[20] = "90";
        posName[21] = "95";posName[22] = "98";
        posName[23] = "94";posName[24] = "96";
        posName[25] = "46";posName[26] = "47";
        posName[27] = "73";posName[28] = "74";
        posName[29] = "84";posName[30] = "85";
        posName[31] = "42";
        posName[32] = "60";
        posName[33] = "21";
        posName[34] = "45";posName[35] = "36";
                           posName[36] = "66";//
                           posName[37] = "61";
                           posName[38] = "62";
                           posName[39] = "67";
                           posName[40] = "63";
                           posName[41] = "59";
                           posName[42] = "64";//bh
                           posName[43] = "S1";
                           posName[44] = "65";
                           posName[45] = "69";
                           posName[46] = "S2";
                           posName[47] = "39";
                           posName[48] = "83";
        posName[49] = "50";
                           posName[50] = "37";
    }
    
    private void getBetragFromKonto()
    {
        Buchung[] b = dats.getBuchungen();
        
        if(b != null)
        {
        for (int i = 0; i < b.length; i++) {
            int per = b[i].getPeriode();
            for (int j = 0; j < perZuBerrechnen.length; j++) {
                if(b[i] != null)
                {
                if(perZuBerrechnen[j] == per)
                {
                    Konto s = b[i].getSoll();
                    Konto h = b[i].getHaben();
                    
                    String pos1 = s.getUstPosVor();
                    setWert(pos1,b[i].getSteuerBetrag());
                    String pos2 = h.getUstPosVor();
                    setWert(pos2,b[i].getSteuerBetrag());                    
                }
                }
            }
        }
        }
    }
    
    public void setWert(String pos, double dBetrag)
    {
        for (int i = 0; i < posName.length; i++) {
            if(posName[i] == pos)
            {
                posWert[i] = posWert[i]+dBetrag;
                break;
            }
        }
    }
    
    public void berechnePositionen()
    {
        this.getBetragFromKonto();
        posWert[1] = (posWert[0]/100)*19;
        posWert[3] = (posWert[2]/100)*7;
        posWert[6] = (posWert[5]);//Sondersteuersätze
            
        posWert[16] = (posWert[15]/100)*19;
        posWert[19] = (posWert[18]/100)*7;
        posWert[22] = (posWert[21]);//Sondersteuersätze
        
        posWert[35] = posWert[1] + posWert[3] +posWert[6] +posWert[22]+posWert[24]+posWert[26]+posWert[28]+posWert[30]+posWert[35];        
        posWert[43] = posWert[35] - (posWert[36] + posWert[37] + posWert[38] + posWert[39] +posWert[40] + posWert[41] + posWert[42]);
        posWert[46] = posWert[43] + posWert[44] + posWert[45];
        
        posWert[48] = posWert[46] - posWert[47];
        
        //pos.putIfAbsent("", "");
    }
    
    public double getWert(String name)
    {
        double rueck = 0;
        
        for (int i = 0; i < posName.length; i++) {
            if(posName[i] != null)
            {
            if(posName[i].compareTo(name) == 0)
            {
                rueck = posWert[i];
                break;
            }
            }
        }
        
        return rueck;
    }
}
