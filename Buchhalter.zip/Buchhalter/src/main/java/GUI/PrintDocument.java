/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUI;
import java.awt.GraphicsEnvironment;
import java.io.FileInputStream;
import javax.print.Doc;
import javax.print.DocFlavor;
import javax.print.DocPrintJob;
import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import javax.print.ServiceUI;
import javax.print.SimpleDoc;
import javax.print.attribute.DocAttributeSet;
import javax.print.attribute.HashDocAttributeSet;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.print.event.PrintJobListener;

import javax.print.event.PrintJobEvent;
/**
 *
 * @author user
 */
public class PrintDocument {
    
    private MyDruckListener drucker = new MyDruckListener();

    public PrintDocument(String strFilename, int iDevice) {

        try {

            PrintRequestAttributeSet pras = new HashPrintRequestAttributeSet();

            //setzt das auszudruckend Dokument fest
            DocFlavor flavor = DocFlavor.INPUT_STREAM.AUTOSENSE; //hier nachsehen, welches man benötigt!

            PrintService printService[] = PrintServiceLookup.lookupPrintServices(
                    flavor, pras);

            PrintService defaultService = PrintServiceLookup.
                    lookupDefaultPrintService();

            PrintService service = null;

            //wenn als Device -1 übergeben wird, wird ein Dialog für das drucken auswählen ausgegeben!
            if (iDevice == -1) {

                service = ServiceUI.printDialog(GraphicsEnvironment.
                        getLocalGraphicsEnvironment().
                        getDefaultScreenDevice().
                        getDefaultConfiguration(), 200, 200,
                        printService, defaultService, flavor, pras);

            } 
            //ansonsten wird der 1te (Standard/Default) Drucker genommen
            else {

                //wenn es keine Drucker gibt und das Device niedriger ist als die Länge
                if (printService != null && printService.length != 0 && printService.length > iDevice) {
                    service = printService[iDevice];
                } 

                //ansonsten standarddevice
                else if (printService != null && printService.length != 0) {
                    service = printService[0];
                }
            }

            //wenn der Dateiename null ist, wird die Druckfunktion beendet!
            if (strFilename == null) {
                return;
            }

            //wenn der Service nicht null ist, wird ausgedruckt
            if (service != null) {
                DocPrintJob job = service.createPrintJob();

                //fügt listener hinzu
                job.addPrintJobListener(drucker);
                FileInputStream fis = new FileInputStream(strFilename);
                DocAttributeSet das = new HashDocAttributeSet();
                Doc doc = new SimpleDoc(fis, flavor, das);
                job.print(doc, pras);
            }
        } //wenn kein Druckerdevice gefunden wurde!!
        catch (ArrayIndexOutOfBoundsException ex) {
            ex.printStackTrace();
            System.out.println("Keine Drucker gefunden!!");
        } 
        //bei sonstigen Exceptions!
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    class MyDruckListener implements PrintJobListener {

        public void printDataTransferCompleted(PrintJobEvent printJobEvent) {
            System.out.println("Daten wurden zum Drucker geschickt!");
        }

        public void printJobCompleted(PrintJobEvent printJobEvent) {
            System.out.println("Drucker hat fertig gedruckt!");
        }

        public void printJobFailed(PrintJobEvent printJobEvent) {
            System.out.println("Fehler beim Drucken!");
        }

        public void printJobCanceled(PrintJobEvent printJobEvent) {
            System.out.println("Abbruch des druckes!");
        }

        public void printJobNoMoreEvents(PrintJobEvent printJobEvent) {
            System.out.println("JobNoMoreEvents!");
        }

        public void printJobRequiresAttention(PrintJobEvent printJobEvent) {
            System.out.println("JobRequieresAttention!");
        }
    }
}
