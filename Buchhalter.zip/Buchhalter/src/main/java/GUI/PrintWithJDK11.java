/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUI;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.PrintJob;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 *
 * @author user
 */
public class PrintWithJDK11 extends Frame
{ 
  public PrintWithJDK11( String sFensterTitel )
  {
    super( sFensterTitel );
    Button bttn = new Button( "Button betätigen, um Ausdruck einer Testseite zu starten ..." );
    add( BorderLayout.CENTER, bttn );
    bttn.addActionListener(
      new ActionListener() {
        public void actionPerformed( ActionEvent ev ) {
          druckeTestseite(); } } );
    addWindowListener(
      new WindowAdapter() {
        public void windowClosing( WindowEvent ev ) {
          dispose();
          System.exit( 0 ); } } );
  }

  void druckeTestseite()
  {
    PrintJob prjob = getToolkit().getPrintJob( this, "Testseite", null );
    if( null != prjob )
    {
      final int iScreenResol           = getToolkit().getScreenResolution();
      final int iPageResol             = prjob.getPageResolution();
      final Dimension dimScreenSize    = getToolkit().getScreenSize();
      final Dimension dimPageDimension = prjob.getPageDimension();
      Graphics pg = prjob.getGraphics();
      if( null != pg && 0 < iPageResol )
      {
        int iAddY = 20;
        int iRand = (int)Math.round( iPageResol * 2. / 2.54 );  // 2 cm Rand
        int iPosX = iRand + iRand/4;                            // Textposition
        int iPosY = iPosX - iAddY/2;
        int iWdth = dimPageDimension.width  - iRand * 2;        // innere Breite
        int iMidY = dimPageDimension.height / 2;
        pg.setFont( new Font( "SansSerif", Font.PLAIN, iAddY*2/3 ) );
        pg.drawString( "Betriebssystem: "
                       + System.getProperty( "os.name" ) + " "
                       + System.getProperty( "os.version" ), iPosX, iPosY+=iAddY );
        pg.drawString( "Java-Version: JDK "
                       + System.getProperty( "java.version" ), iPosX, iPosY+=iAddY );
        pg.drawString( "getScreenResolution: "
                       + iScreenResol + " dpi", iPosX, iPosY+=iAddY );
        pg.drawString( "getScreenSize: "
                       + dimScreenSize.width  + " x "
                       + dimScreenSize.height + " Pixel", iPosX, iPosY+=iAddY );
        pg.drawString( "PrintJob.getPageResolution: "
                       + iPageResol + " dpi", iPosX, iPosY+=iAddY );
        pg.drawString( "PrintJob.getPageDimension: "
                       + dimPageDimension.width  + " x "
                       + dimPageDimension.height + " Pixel", iPosX, iPosY+=iAddY );
        pg.drawString( "errechnete Papiergröße: "
                       + Math.round( 254. * dimPageDimension.width  / iPageResol / 10. ) + " x "
                       + Math.round( 254. * dimPageDimension.height / iPageResol / 10. ) + " mm",
                       iPosX, iPosY+=iAddY );
        pg.drawRect( iRand, iRand, iWdth, dimPageDimension.height - iRand * 2 );
        pg.drawLine( iRand, iMidY + iWdth/50, dimPageDimension.width - iRand, iMidY - iWdth/50 );
        pg.drawLine( iRand, iMidY - iWdth/50, dimPageDimension.width - iRand, iMidY + iWdth/50 );
        iWdth -= 4;
        pg.drawOval( iRand + 2, dimPageDimension.height - iRand - iWdth - 2, iWdth, iWdth );
        pg.dispose();
      }
      prjob.end();
    }
  }
}