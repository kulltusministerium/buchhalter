/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Daten;

import Fachkonzept.Konto;

/**
 *
 * @author user
 */
public class Vorlage {
    private String soll;
    private String haben;
    private String sText;
    private int iSteuer;
    private double dBetrag;
    
    public Vorlage(String text,String s, String h,int steuer,double betrag)
    {
        this.soll = s;
        this.haben = h;
        this.sText = text;
        this.iSteuer = steuer;
        this.dBetrag = betrag;
    }

    public void printAll()
    {
        System.out.println(soll+"/"+haben+" "+sText+" " +iSteuer+ " " +dBetrag);
    }
    
    public String getSoll() {
        return soll;
    }

    public void setSoll(String soll) {
        this.soll = soll;
    }

    public String getHaben() {
        return haben;
    }

    public void setHaben(String haben) {
        this.haben = haben;
    }

    public String getsText() {
        return sText;
    }

    public void setsText(String sText) {
        this.sText = sText;
    }

    public int getiSteuer() {
        return iSteuer;
    }

    public void setiSteuer(int iSteuer) {
        this.iSteuer = iSteuer;
    }

    public double getdBetrag() {
        return dBetrag;
    }

    public void setdBetrag(double dBetrag) {
        this.dBetrag = dBetrag;
    }
    
    
}
