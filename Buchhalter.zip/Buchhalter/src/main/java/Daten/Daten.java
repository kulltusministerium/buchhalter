/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Daten;

import Fachkonzept.Artikel;
import Fachkonzept.Auftrag;
import Fachkonzept.Buchung;
import Fachkonzept.Konto;
import Fachkonzept.Kunde;
import Fachkonzept.Position;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author user
 */
public class Daten {
    private Buchung[] buchungen;
    private Konto[] konten;
    private Vorlage[] vorlagen;
    private Auftrag[] auftraege;
    private Kunde[] kunden;
    private Artikel[] artikel;
    
    private int iAnzahlKonten;
    private int iAnzahlBuchungen;
    private int iAnzahlVorlagen;
    private int iAnzahlAuftraege;
    private int iAnzahlArtikel;
    private int iAnzahlKunden;
    private int iAnzahlPOS;
    
    private int iNummerBuchung;
    private static Daten instanz;
    
    private String ortStapel;
    private String ortKonten;
    private String ortVorlagen;
    private String ortFirma;
    private String ortAuftraege;
    private String ortArtikel;
    private String ortKunden;
    
    private int currYear = 2023;
    //Firmenangaben
    private String sFirmaName = "Musterfirma";
    private String sAdresse = "Musterstraße 1,74564 Crailsheim";
    private String sTelefon = "07951 / 7777";
    private String sMail = "info@muster.de";
    private String sSteuerNr = "57 000 10008";
    private String sAmt = "Finanzamt Schwäbisch Hall, Bahnhofstraße 25, 74523 Schwäbisch Hall";
    
    public int getAnzahlArtikel()
    {
        return iAnzahlArtikel;
    }
    
    public Artikel[] getArtikel()
    {
        return artikel;
    }
    
    public void setAnzAuftraege(int anz)
    {
        this.iAnzahlAuftraege = anz;
    }
    
    public int getAnzAuftraege()
    {
        return iAnzahlAuftraege;
    }
    
    public void setAdresse(String adr)
    {
        this.sAdresse = adr;
    }
    
    public String getFirma()
    {
        return sFirmaName;
    }
    
    public String getAdresse()
    {
        return sAdresse;
    }
    
    public String getTelefon()
    {
        return sTelefon;
    }
    
    public String getMail()
    {
        return sMail;
    }
    
    public String getSteuer()
    {
        return sSteuerNr;
    }
    
    public String getAmt()
    {
        return sAmt;
    }

    public void setsFirmaName(String sFirmaName) {
        this.sFirmaName = sFirmaName;
    }

    public void setsTelefon(String sTelefon) {
        this.sTelefon = sTelefon;
    }

    public void setsMail(String sMail) {
        this.sMail = sMail;
    }

    public void setsSteuerNr(String sSteuerNr) {
        this.sSteuerNr = sSteuerNr;
    }

    public void setsAmt(String sAmt) {
        this.sAmt = sAmt;
    }
    
    public int getYear()
    {
        return currYear;
    }
    
    public void setAnzKonten(int anz)
    {
        this.iAnzahlKonten = anz;
    }
    
    public void setAnzBuchung(int anz)
    {
        this.iAnzahlBuchungen = anz;
        this.iAnzahlAuftraege = anz;
    }
    
    public static Daten getInstanz()
    {
        return instanz;
    }
    
    public void setOrtStapel(String path)
    {
        this.ortStapel = path;
    }
    
    public String getOrtStapel()
    {
        return ortStapel;
    }
    
    public void setOrtRahmen(String path)
    {
        this.ortKonten = path;
    }
    
    public String getOrtKonten()
    {
        return ortKonten;
    }
    
    public Buchung[] getBuchungen()
    {
        return buchungen;
    }
    
    public Konto[] getKonten()
    {
        return konten;
    }
    
    public void Jahreswechsel()
    {
        this.speichereStapelWechsel();
        this.resetStapel();
        this.currYear++;
        
    }
    
    public int getJahr()
    {
        return currYear;
    }
    
    public String[] getVorlagenTexte()
    {
        String[] rueck = new String[vorlagen.length];
        
        for (int i = 0; i < vorlagen.length; i++) {
            if(vorlagen[i] != null)
            {
                rueck[i] = vorlagen[i].getsText();
            }
        }
        
        return rueck;
    }
    
    public String[] getKontenNr()
    {
        String[] rueck = new String[iAnzahlKonten];
        
        for (int i = 0; i < konten.length; i++) {
            if(konten[i] != null)
            {
                rueck[i] = konten[i].getNummer();
            }
        }
        return rueck;
    }
    
    public Daten()
    {
        
        //SQL com = new SQL();
        //com.connect();
        
        ortKonten = "C:\\Users\\user\\Documents\\NetBeansProjects\\Buchhalter\\src\\main\\java\\Daten\\Kontenrahmen.txt";
        ortStapel = "C:\\Users\\user\\Documents\\NetBeansProjects\\Buchhalter\\src\\main\\java\\Daten\\Stapel.txt";
        ortVorlagen = "C:\\Users\\user\\Documents\\NetBeansProjects\\Buchhalter\\src\\main\\java\\Daten\\Vorlagen.txt";
        ortFirma = "C:\\Users\\user\\Documents\\NetBeansProjects\\Buchhalter\\src\\main\\java\\Daten\\Firmendaten.txt";
        ortAuftraege = "C:\\Users\\user\\Documents\\NetBeansProjects\\Buchhalter\\src\\main\\java\\Daten\\Auftraege.txt";
        ortArtikel = "C:\\Users\\user\\Documents\\NetBeansProjects\\Buchhalter\\src\\main\\java\\Daten\\Artikel.txt";
        ortKunden = "C:\\Users\\user\\Documents\\NetBeansProjects\\Buchhalter\\src\\main\\java\\Daten\\Artikel.txt";
        
        iAnzahlKonten = 10000;
        iAnzahlBuchungen = 50000;
        iAnzahlAuftraege = 50000;
        iAnzahlVorlagen = 10000;
        iAnzahlKunden = 10000;
        iAnzahlArtikel = 100000;
        iAnzahlPOS = 500;
        loadFirmenDaten();
        
        kunden = new Kunde[iAnzahlKunden];
        artikel = new Artikel[iAnzahlVorlagen];
        auftraege = new Auftrag[iAnzahlAuftraege];
        buchungen = new Buchung[iAnzahlBuchungen];
        konten = new Konto[iAnzahlKonten];
        vorlagen = new Vorlage[iAnzahlVorlagen];
        
        iNummerBuchung = 1;
        loadKontenFromFile();
        loadBuchungenFromFile();
        loadVorlagenFromFile();
        loadKundenFromFile();
        loadArtikelFromFile();
        loadAuftraegeFromFile();
        instanz = this;
    }
    
    
    
    public Vorlage getVorlage(String text)
    {
        Vorlage rueck = null;
        for (int i = 0; i < vorlagen.length; i++) {
            if(vorlagen[i].getsText().contains(text))
            {
                rueck = vorlagen[i];
                break;
            }
        }
        
        return rueck;
    }
    
    public String getOrtVorlagen()
    {
        return ortVorlagen;
    }
    
    public void setOrtVorlagen(String ort)
    {
        this.ortVorlagen = ort;
    }
    
    public int getAnzKonten()
    {
        return iAnzahlKonten;
    }
    
    public int getAnzBuchungen()
    {
        return iAnzahlBuchungen;
    }

    public String getOrtFirma() {
        return ortFirma;
    }

    public void setOrtFirma(String ortFirma) {
        this.ortFirma = ortFirma;
    }

    public int getiAnzahlVorlagen() {
        return iAnzahlVorlagen;
    }

    public void setiAnzahlVorlagen(int iAnzahlVorlagen) {
        this.iAnzahlVorlagen = iAnzahlVorlagen;
    }
    
    public void addKonto(Konto k)
    {
        for (int i = 0; i < konten.length; i++) {
            if(konten[i] == null)
            {
                konten[i] = k;
                break;
            }
        }
    }
    
    public void addBuchung(Buchung b)
    {
        for (int i = 0; i < buchungen.length; i++) {
            if(buchungen[i] == null)
            {
                buchungen[i] = b;
                iNummerBuchung++;
                //System.out.println(b.getAllInfos());
                break;
            }
        }
    }
    
    public int getNummerBuchung()
    {
        return iNummerBuchung;
    }
    
    public Konto getKonto(String sNummer)
    {
        Konto rueck = null;
                
        for (int i = 0; i < konten.length; i++) {
            if(konten[i] != null)
            {
            if(konten[i].getNummer() == sNummer)
            {
                rueck = konten[i];
                break;
            }
            }               
        }
        
        return rueck;
    }
    
    public Vorlage getVorlageByText(String sText)
    {
        Vorlage rueck = null;
        for (int i = 0; i < vorlagen.length; i++) {
            if(vorlagen[i].getsText() == sText)
            {
                rueck = vorlagen[i];
                break;
            }
        }
        return rueck;
    }
    
    public Buchung[] getBuchungByKonto(String nr)
    {
        Buchung[] rueck = new Buchung[iAnzahlBuchungen];
        int j = 0;
        
        for (int i = 0; i < buchungen.length; i++) {
            if(buchungen[i] != null)
            {
            if(buchungen[i].getSoll().getNummer() == nr)
            {
                rueck[j] = buchungen[i];
                j++;
            }
            
            if(buchungen[i].getHaben().getNummer() == nr)
            {
                rueck[j] = buchungen[i];
                j++;
            }
            }
            else
                break;
        }
        
        return rueck;
    }
    
    public Buchung getBuchungByNr(int iNummer)
    {
        Buchung rueck = null;
        for (int i = 0; i < buchungen.length; i++) {
            if(buchungen[i].getNummer() == iNummer)
            {
                rueck = buchungen[i];
                break;
            }
        }        
        return rueck;
    }
    
    public Konto getKontoByNr(String nr)
    { 
        Konto rueck = null;
        
        for (int i = 0; i < konten.length; i++) {
            if(konten[i] != null)
            {
                if(konten[i].getNummer().toString().equals(nr))
                {    
                    rueck = konten[i];
                    break;
                }
            }
            else
                break;
            
        }
        return rueck;
    }
    
    public Konto getKontoByBez(String bez)
    {
        Konto rueck = null;
        
        for (int i = 0; i < konten.length; i++) {
            if(konten[i] != null)
            {
                if(konten[i].getBezeichnung().compareTo(bez) == 0)
                {
                    rueck = konten[i];
                    break;
                }
            }
        }
        
        return rueck;
    }
    
    public Konto[] getKontoBereich(int iMin, int iMax)
    {
        Konto[] rueck = new Konto[iAnzahlKonten];
        int iZaehler = 0;
        for (int i = 0; i < konten.length; i++) {
            if(konten[i] != null)
            {
            if(Integer.parseInt(konten[i].getNummer()) >= iMin)
            {
                if(Integer.parseInt(konten[i].getNummer())<=iMax)
                {
                    rueck[iZaehler] = konten[i];
                    iZaehler++;
                }
            }
            }
        }
        
        return rueck;
    }
    
    public Konto[] getKontoByArt(String sArt)
    {
        Konto[] rueck = new Konto[iAnzahlKonten];
        int j = 0;
        
        switch(sArt)
        {
            case "Sachkonto":
                for (int i = 0; i < konten.length; i++) {
                    if(konten[i] != null)
                    {
                    if(konten[i].getNummer().length() < 5)
                    {
                        if(rueck[j] == null)
                        {
                            rueck[j] = konten[i];
                            j++;                            
                        }
                    }
                    }
                    else
                        break;
                }
                break;
            case "Debitor":
                for (int i = 0; i < konten.length; i++) {
                    if(konten[i] != null)
                    {
                    if((konten[i].getNummer().length() == 5) && (Integer.parseInt(konten[i].getNummer()) < 7000))
                    {
                        if(rueck[j] == null)
                        {
                            rueck[j] = konten[i];
                            j++;                            
                        }
                    }
                    }
                    else
                        break;
                }
                break;
            case "Kreditor":   
                for (int i = 0; i < konten.length; i++) {
                    if(konten[i] != null)
                    {
                    if((konten[i].getNummer().length() == 5) && (Integer.parseInt(konten[i].getNummer()) >= 7000))
                    {
                        if(rueck[j] == null)
                        {
                            rueck[j] = konten[i];
                            j++;                            
                        }
                    }
                    }
                    else
                        break;
                }
                break;
        }
        
        return rueck;
    }
    
    public void printAllKonten()
    {
        for (int i = 0; i < konten.length; i++) {
            if(konten[i] != null)
            {
                System.out.println(konten[i].getNummer() + " " + konten[i].getBezeichnung() + " Saldo: " + konten[i].getSaldo());
            }
        }
    }
    
    public void printAllBuchungen()
    {
        for (int i = 0; i < buchungen.length; i++) {
            if(buchungen[i] != null)
            {
                System.out.println(buchungen[i].getAllInfos());
            }
        }
    }
    
    public Vorlage[] getVorlagen()
    {
        return vorlagen;
    }
    
    public void addVorlage(Vorlage v)
    {
        for (int i = 0; i < vorlagen.length; i++) {
            if(vorlagen[i] == null)
            {
                vorlagen[i] = v;
                break;
            }
        }
    }
    
    public void loadVorlagenFromFile()
    {        
        try
        {
        // Open the file
        FileInputStream fstream = new FileInputStream(ortVorlagen);
        BufferedReader br = new BufferedReader(new InputStreamReader(fstream));

        String strLine;
        
        //Read File Line By Line
        while ((strLine = br.readLine()) != null)   {
        // Print the content on the console
            String[] split = strLine.split(";");
            String sText = split[0];
            String s =split[1];
            String h = split[2];            
            double dBetr = Double.parseDouble(split[3]);
            int steuer = Integer.parseInt(split[4]);
            //Vorlage v = new Vorlage(s,h,sText,steuer,dBetr);
            Vorlage v = new Vorlage(sText,s,h,steuer,dBetr);
            addVorlage(v);
        }

        //Close the input stream
        fstream.close();
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }

    public void loadKontenFromFile()
    {
        try
        {
        // Open the file
        FileInputStream fstream = new FileInputStream(ortKonten);
        BufferedReader br = new BufferedReader(new InputStreamReader(fstream));

        String strLine;
        //Read File Line By Line
        while ((strLine = br.readLine()) != null)   {
        // Print the content on the console
            String[] alg =strLine.split("#");
            String[] split = alg[0].split(";");
            
            Konto k = new Konto(split[0], split[1],iAnzahlBuchungen);
            
            try
            {
                //System.out.println(split[2]);
                k.setSteuerPos(split[2]);
            }
            catch(Exception e)
            {}
            
            addKonto(k);
        }

        //Close the input stream
        fstream.close();
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void loadBuchungenFromFile()
    {
        try
        {
        // Open the file
        FileInputStream fstream = new FileInputStream(ortStapel);
        BufferedReader br = new BufferedReader(new InputStreamReader(fstream));

        String strLine;

        //Read File Line By Line
        while ((strLine = br.readLine()) != null)   {
        // Print the content on the console
            String[] split = strLine.split(";");
            int nr = Integer.parseInt(split[0]);
            String datum = split[1];
            String text = split[2];
            Konto soll = getKontoByNr(split[3]);
            Konto haben = getKontoByNr(split[4]);
            
            Buchung b = new Buchung(Integer.parseInt(split[0]), split[1],split[2],soll,haben,Double.parseDouble(split[5]),Integer.parseInt(split[6]));
            addBuchung(b);
            //System.out.println(b.getAllInfos());
        }

        //Close the input stream
        fstream.close();
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void saveKonten()
    {
        try
        {
        File fout = new File(ortKonten);
	FileOutputStream fos = new FileOutputStream(fout);
 
	OutputStreamWriter osw = new OutputStreamWriter(fos);
 
	for (int i = 0; i < konten.length; i++) {
            if(konten[i] != null)
            {
                String sText = konten[i].getNummer()+";"+konten[i].getBezeichnung()+"#"+konten[i].getSteuerPosMod()+"\n";
		osw.write(sText);
            }
            else
                break;
	}
 
	osw.close();
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void saveStapel()
    {        
        try
        {
        File fout = new File(ortStapel);
	FileOutputStream fos = new FileOutputStream(fout);
 
	OutputStreamWriter osw = new OutputStreamWriter(fos);
 
	for (int i = 0; i < buchungen.length; i++) {
            if(buchungen[i] != null)
            {
            String sText = buchungen[i].getNummer()+";"+buchungen[i].getDatum()+";"+buchungen[i].getText()+";"+buchungen[i].getSoll().getNummer()+";"+buchungen[i].getHaben().getNummer()+";"+buchungen[i].getBetrag()+";"+buchungen[i].getSteuer()+";"+true+"\n";
		osw.write(sText);
            }
            else
                break;
	}
 
	osw.close();
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void saveVorlagen()
    {
        try
        {
        File fout = new File(ortVorlagen);
	FileOutputStream fos = new FileOutputStream(fout);
 
	OutputStreamWriter osw = new OutputStreamWriter(fos);
 
	for (int i = 0; i < vorlagen.length; i++) {
            if(vorlagen[i] != null)
            {
                String sText = vorlagen[i].getsText()+";"+vorlagen[i].getSoll()+";"+vorlagen[i].getHaben()+";"+vorlagen[i].getdBetrag()+";"+vorlagen[i].getiSteuer();
		osw.write(sText);
            }
            else
                break;
	}
 
	osw.close();
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void saveFirmenDaten()
    {
        try
        {
        File fout = new File(ortFirma);
	FileOutputStream fos = new FileOutputStream(fout);
 
	OutputStreamWriter osw = new OutputStreamWriter(fos);
 
	osw.write(sFirmaName+"\n");
        osw.write(sAdresse+"\n");
        osw.write(sTelefon+"\n");
        osw.write(sMail+"\n");
        osw.write(sSteuerNr+"\n");
        osw.write(sAmt+"\n");
        osw.write(currYear+"\n");
        osw.write(ortKonten+"\n");
        osw.write(ortStapel+"\n");
        osw.write(ortVorlagen+"\n");
        osw.write(ortFirma+"\n");
        osw.write(iAnzahlKonten+"\n");
        osw.write(iAnzahlBuchungen+"\n");
        osw.write(iAnzahlVorlagen+"\n");
        
	osw.close();
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void setOrtArtikel(String ort)
    {
        this.ortArtikel = ort;
    }
    
    public void setOrtAuftraege(String ort)
    {
        this.ortAuftraege = ort;
    }
    
    public void setOrtKunden(String ort)
    {
        this.ortKunden = ort;
    }
    
    public void setAnzahlArtikel(int anz)
    {
        this.iAnzahlArtikel = anz;
    }
    
    public void setAnzahlKunden(int anz)
    {
        this.iAnzahlKunden = anz;
    }
    
    public void loadFirmenDaten()
    {
        try
        {
        // Open the file
        FileInputStream fstream = new FileInputStream(ortFirma);
        BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
        
        this.setsFirmaName(br.readLine());
        this.setAdresse(br.readLine());
        this.setsTelefon(br.readLine());
        this.setsMail(br.readLine());
        this.setsSteuerNr(br.readLine());
        this.setsAmt(br.readLine());
        this.currYear = Integer.parseInt(br.readLine());        
        this.setOrtRahmen(br.readLine());
        this.setOrtStapel(br.readLine());
        this.setOrtVorlagen(br.readLine());
        this.setOrtFirma(br.readLine());        
        this.setOrtArtikel(br.readLine());
        this.setOrtAuftraege(br.readLine());
        this.setOrtKunden(br.readLine());        
        this.setAnzKonten(Integer.parseInt(br.readLine()));
        this.setAnzBuchung(Integer.parseInt(br.readLine()));        
        this.setiAnzahlVorlagen(Integer.parseInt(br.readLine()));        
        this.setAnzAuftraege(Integer.parseInt(br.readLine()));
        this.setAnzahlArtikel(Integer.parseInt(br.readLine()));
        this.setAnzahlKunden(Integer.parseInt(br.readLine()));
        this.setAnzahlPOS(Integer.parseInt(br.readLine()));
        
        //Close the input stream
        fstream.close();
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void setAnzahlPOS(int anzahl)
    {
        this.iAnzahlPOS = anzahl;
    }
    
    public void speichereStapelWechsel()
    {
        try
        {
        File fout = new File("C:\\Users\\user\\Documents\\NetBeansProjects\\Buchhalter\\src\\main\\java\\Daten\\Stapel_"+currYear+".txt");
	FileOutputStream fos = new FileOutputStream(fout);
 
	OutputStreamWriter osw = new OutputStreamWriter(fos);
 
	for (int i = 0; i < buchungen.length; i++) {
            if(buchungen[i] != null)
            {
            String sText = buchungen[i].getNummer()+";"+buchungen[i].getDatum()+";"+buchungen[i].getText()+";"+buchungen[i].getSoll().getNummer()+";"+buchungen[i].getHaben().getNummer()+";"+buchungen[i].getBetrag()+";"+buchungen[i].getSteuer()+";"+true+"\n";
		osw.write(sText);
            }
            else
                break;
	}
 
	osw.close();
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void resetStapel()
    {
    
    }
    
    public Auftrag[] getAuftragByArt(String art)
    {
        Auftrag[] rueck = new Auftrag[this.iAnzahlAuftraege];
        int zaehler = 0;
        
        for (int i = 0; i < auftraege.length; i++) {
            if(auftraege[i].getArt().compareTo(art) == 0)
            {
                rueck[zaehler] = auftraege[i];
            }
        }
        
        return rueck;
    }
    
    public Auftrag[] getAuftraege()
    {
        return auftraege;
    }
    
    public void addAuftrag(Auftrag a)
    {
        for (int i = 0; i < auftraege.length; i++) {
            if(auftraege[i] == null)
            {
                auftraege[i] = a;
                break;
            }
        }
    }
    
    public Kunde getKundeByNr(int iNr)
    {
        Kunde rueck = null;
        for (int i = 0; i < kunden.length; i++) {
            if(kunden[i] != null)
            {
                if(kunden[i].getiNummer() == iNr)
                {
                    rueck = kunden[i];
                    break;
                }
            }
        }
        return rueck;
    }
    
    public Artikel getArtikelByNr(int iNr)
    {
        Artikel rueck = null;
        for (int i = 0; i < artikel.length; i++) {
            if(artikel[i] != null)
            {
                rueck = artikel[i];
                break;
            }
        }
        return rueck;
    }
    
    public void addArtikel(Artikel a)
    {
        for (int i = 0; i < artikel.length; i++) {
            if(artikel[i] == null)
            {
                artikel[i] = a;
                break;
            }
        }
    }
    
    public void addKunde(Kunde k)
    {
        for (int i = 0; i < kunden.length; i++) {
            if(kunden[i] == null)
            {
                kunden[i] = k;
                break;
            }
        }
    }
    
    public Auftrag getAuftragByNr(int iNr)
    {
        Auftrag rueck = null;
        
        for (int i = 0; i < auftraege.length; i++) {
            if(auftraege[i] != null)
            {
                if(auftraege[i].getiNummer() == iNr)
                {
                    rueck = auftraege[i];
                    break;
                }
            }
        }
        
        return rueck;
    }
    
    public Auftrag getAuftragByIndex(int iNr)
    {
        return auftraege[iNr];
    }
    
    public Kunde[] getKunden()
    {
        return kunden;
    }
    
    public int getAnzahlKunden()
    {
        return this.iAnzahlKunden;
    }
    
    public Artikel getArtikelByIndex(int index)
    {
        return artikel[index];
    }
    
    public void saveAuftraegeToFile()
    {
        try
        {
        File fout = new File(ortAuftraege);
	FileOutputStream fos = new FileOutputStream(fout);
 
	OutputStreamWriter osw = new OutputStreamWriter(fos);
        String output = "";
	//osw.write(sFirmaName+"\n");      
        
            for (int i = 0; i < auftraege.length; i++) {
                if(auftraege[i] != null)
                {
                    output = auftraege[i].getArt() + ";" + auftraege[i].getiNummer() + ";" + auftraege[i].getsDatum() + ";" + auftraege[i].getKunde().getiNummer()+ ";";
                    Position[] pos = auftraege[i].getPositionen();
                    
                    for (int j = 0; j < pos.length; j++) {
                        if(pos[i] != null)
                        {
                            output = output + pos[i].getArtikel().getNr() + "-" + pos[i].getiMenge() + "-" + pos[i].getiRabatt() + "#";
                        }
                    }
                    osw.write(output +"\n");
                }
            }
        
	osw.close();
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void loadAuftraegeFromFile()
    {
        try
        {
        // Open the file
        FileInputStream fstream = new FileInputStream(ortAuftraege);
        BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
        
        Auftrag a;
        Position p;
        
        String strLine;

        //Read File Line By Line
        while ((strLine = br.readLine()) != null)   {
            // Print the content on the console
            String sRead[] = strLine.split(";");
        
            a = new Auftrag();
            
            a.setArt(sRead[0]);
            a.setiNummer(Integer.parseInt(sRead[1]));
            a.setsDatum(sRead[2]);
            a.setKunde(getKundeByNr(Integer.parseInt(sRead[3])));
            
            String[] posGes = new String[iAnzahlPOS];
            
            posGes = sRead[4].split("#");
            for (int i = 0; i < posGes.length; i++) {
            String[] pos = posGes[i].split("-");
            p = new Position();
            p.setArtikel(getArtikelByNr(Integer.parseInt(pos[0])));
            p.setMenge(Integer.parseInt(pos[1]));
            p.setRabatt(Integer.parseInt(pos[2]));
            
            a.addPosition(p); 
            }
            
            this.addAuftrag(a);   
        }
        //Close the input stream
        fstream.close();
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, "Auftrag: " +e.getMessage());
        }
    }
    
    public void speicherArtikelToFile()
    {
        try
        {
            File fout = new File(ortArtikel);
            FileOutputStream fos = new FileOutputStream(fout);
 
            OutputStreamWriter osw = new OutputStreamWriter(fos);
 
            String output = "";
            for (int i = 0; i < artikel.length; i++) {
                if(artikel[i] != null)
                {
                    output = artikel[i].getNr() + ";" + artikel[i].getBezeichnung()+ ";" + artikel[i].getsBeschreibung()+ ";" + artikel[i].getdStueckpreisNetto()+ ";" + artikel[i].getiSteuersatz();
                    osw.write(output + "\n");
                }
            }
        
            //osw.write(sFirmaName+"\n");      
        
            osw.close();
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void loadArtikelFromFile()
    {
        try
        {
        // Open the file
        FileInputStream fstream = new FileInputStream(ortArtikel);
        BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
        
        Artikel a;
        
        String strLine;

        //Read File Line By Line
        while ((strLine = br.readLine()) != null)   {
            // Print the content on the console
            String sRead[] = strLine.split(";");
            int iNr = Integer.parseInt(sRead[0]);
            String bez = sRead[1];
            String beschr = sRead[2];
            double preis = Double.parseDouble(sRead[3]);
            int steuer = Integer.parseInt(sRead[4]);
            a = new Artikel(iNr,bez,beschr,preis,steuer);
            addArtikel(a);
        }
        //Close the input stream
        fstream.close();
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void saveKundenToFile()
    {
        try
        {
            File fout = new File(ortKunden);
            FileOutputStream fos = new FileOutputStream(fout);
 
            OutputStreamWriter osw = new OutputStreamWriter(fos);
 
            String output = "";
            for (int i = 0; i < kunden.length; i++) {
                if(kunden[i] != null)
                {
                    output = kunden[i].getiNummer() + ";" + kunden[i].getAnrede() + ";" + kunden[i].getName() + ";" + kunden[i].getVorname() + ";" + kunden[i].getStrasse() + ";" + kunden[i].getHausnr() + ";" + kunden[i].getPlz() + ";" + kunden[i].getOrt();
                    osw.write(output + "\n");
                }
            }        
            //osw.write(sFirmaName+"\n");
            osw.close();
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void loadKundenFromFile()
    {
        try
        {
        // Open the file
        FileInputStream fstream = new FileInputStream(ortKunden);
        BufferedReader br = new BufferedReader(new InputStreamReader(fstream));
        
        Kunde k;
        
        String strLine;

        //Read File Line By Line
        while ((strLine = br.readLine()) != null)   {
            // Print the content on the console
            String sRead[] = strLine.split(";");
            k = new Kunde();
            System.out.println(sRead[6]);
            k.setiNummer(Integer.parseInt(sRead[0]));
            k.setAnrede(sRead[1]);
            k.setName(sRead[2]);
            k.setVorname(sRead[3]);
            k.setStrasse(sRead[4]);
            k.setHausnr(sRead[5]);
            k.setPlz(sRead[6]);
            k.setOrt(sRead[7]);
            
            addKunde(k);
        }
        fstream.close();
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
    }
}